/* Frontend sem build: JS puro + Tailwind (CDN). Todo texto dinâmico passa por esc(). */
const $ = (s, el = document) => el.querySelector(s);
const $$ = (s, el = document) => [...el.querySelectorAll(s)];
const esc = (v) => String(v ?? "").replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
const fmt = (n) => (n == null ? "—" : Number(n).toLocaleString("pt-BR"));
const fmtData = (iso) => (iso ? iso.split("-").reverse().join("/") : "—");
const PAGE = 50;

const state = {
  token: sessionStorage.getItem("token"), user: null, filiais: [], status: {},
  veiculos: [], kpis: {}, criterios: [], busca: "", statusFiltro: "TODOS",
  sort: { col: "urgencia", dir: "desc" }, page: 0, filial: "", baixaAlvo: null,
};

/* ------------------------------ infraestrutura ------------------------------ */
async function api(path, opts = {}) {
  const headers = { "Content-Type": "application/json", ...(state.token ? { Authorization: "Bearer " + state.token } : {}) };
  const r = await fetch(path, { ...opts, headers, body: opts.body ? JSON.stringify(opts.body) : undefined });
  const data = await r.json().catch(() => ({}));
  if (r.status === 401 && state.token) { logout(); throw new Error(data.erro || "Sessão expirada."); }
  if (!r.ok) { const e = new Error(data.erro || "Erro inesperado."); e.data = data; e.status = r.status; throw e; }
  return data;
}
function toast(msg, tipo = "ok") {
  const el = document.createElement("div");
  el.className = "toast"; el.style.background = { ok: "#10B981", erro: "#EF4444", aviso: "#F59E0B" }[tipo];
  el.textContent = msg; $("#toasts").append(el);
  setTimeout(() => { el.style.opacity = 0; el.style.transition = "opacity .3s"; setTimeout(() => el.remove(), 300); }, 3800);
}
let loads = 0;
const loading = (on) => { loads = Math.max(0, loads + (on ? 1 : -1)); $("#loader").classList.toggle("hidden", loads === 0); };
const debounce = (fn, ms = 150) => { let t; return (...a) => { clearTimeout(t); t = setTimeout(() => fn(...a), ms); }; };
const abrir = (id) => $(id).classList.remove("hidden");
const fechar = (el) => el.closest(".modal").classList.add("hidden");

/* ------------------------------------ auth ----------------------------------- */
$("#login-form").addEventListener("submit", async (e) => {
  e.preventDefault(); const btn = $("#login-btn"); btn.disabled = true; $("#login-erro").classList.add("hidden");
  try {
    const d = await api("/api/login", { method: "POST", body: { email: $("#login-email").value, senha: $("#login-senha").value } });
    state.token = d.token; sessionStorage.setItem("token", d.token); await iniciar();
  } catch (err) { const el = $("#login-erro"); el.textContent = err.message; el.classList.remove("hidden"); }
  finally { btn.disabled = false; }
});
function logout() {
  sessionStorage.removeItem("token"); state.token = null;
  $("#view-app").classList.add("hidden"); $("#view-login").classList.remove("hidden");
}
$("#btn-sair").addEventListener("click", logout);

async function iniciar() {
  if (!state.token) return logout();
  loading(true);
  try {
    const me = await api("/api/me");
    Object.assign(state, { user: me.usuario, filiais: me.filiais, status: me.status });
    $("#user-nome").textContent = me.usuario.nome;
    $("#user-perfil").textContent = me.usuario.perfil === "GLOBAL" ? "Gestor global" : me.usuario.filial;
    const opts = (me.usuario.perfil === "GLOBAL" ? [`<option value="">Todas as filiais</option>`] : [])
      .concat(me.filiais.map((f) => `<option value="${esc(f)}">${esc(f)}</option>`));
    $("#filtro-filial").innerHTML = opts.join("");
    $("#filtro-filial").disabled = me.usuario.perfil !== "GLOBAL";
    const sel = me.filiais.map((f) => `<option value="${esc(f)}">${esc(f)}</option>`).join("");
    $("#veic-filial").innerHTML = sel;
    $("#crit-filial").innerHTML = (me.usuario.perfil === "GLOBAL" ? `<option value="*">Todas (padrão)</option>` : "") + sel;
    state.filial = me.usuario.perfil === "GLOBAL" ? "" : me.usuario.filial;
    $("#view-login").classList.add("hidden"); $("#view-app").classList.remove("hidden");
    $("#login-senha").value = "";
    await Promise.all([carregarPainel(), carregarCriterios()]);
  } catch (e) { toast(e.message, "erro"); logout(); }
  finally { loading(false); }
}

/* ---------------------------------- painel ----------------------------------- */
async function carregarPainel() {
  const q = state.filial ? "?filial=" + encodeURIComponent(state.filial) : "";
  const d = await api("/api/veiculos" + q);
  state.veiculos = d.veiculos; state.kpis = d.kpis; state.page = 0;
  renderKpis(); renderChips(); renderTabela(); renderAvisos();
}
$("#filtro-filial").addEventListener("change", async (e) => {
  state.filial = e.target.value; loading(true);
  try { await carregarPainel(); } catch (err) { toast(err.message, "erro"); } finally { loading(false); }
});

function renderKpis() {
  const k = state.kpis;
  const cards = [
    ["TODOS", "Total de veículos", k.total, "#0f172a"],
    ["REGULAR", "Ativos em dia", k.regulares, "#10B981"],
    ["ALERTA", "Alerta preventivo", k.alerta, "#F59E0B"],
    ["CRITICO", "Críticos", k.criticos, "#EF4444"],
    ["DESATIVADO", "Desativados", k.desativados, "#6B7280"],
  ];
  $("#kpis").innerHTML = cards.map(([f, rot, n, cor]) => `
    <button class="kpi fade-in" style="border-left-color:${cor}" data-f="${f}">
      <div class="text-xs text-slate-500">${rot}</div><div class="text-3xl font-bold mt-1" style="color:${cor}">${fmt(n)}</div>
    </button>`).join("");
  $$("#kpis .kpi").forEach((b) => b.addEventListener("click", () => { state.statusFiltro = b.dataset.f; state.page = 0; renderChips(); renderTabela(); }));
}
function renderAvisos() {
  const k = state.kpis, av = [];
  if (k.sem_criterio) av.push(`${fmt(k.sem_criterio)} veículo(s) sem critério de revisão (ferramentas, equipamentos ou chassi sem cadastro).`);
  if (k.sem_leitura_km) av.push(`${fmt(k.sem_leitura_km)} veículo(s) sem leitura de KM nos abastecimentos — avaliados só por tempo.`);
  if (k.km_suspeito) av.push(`${fmt(k.km_suspeito)} veículo(s) com KM suspeita (maior leitura > 2× a anterior). Confira o hodômetro.`);
  const prov = state.criterios.filter((c) => c.revisar === "SIM").length;
  if (prov) av.push(`${prov} critério(s) com valores provisórios do carregamento inicial — revise na aba Critérios.`);
  $("#avisos").innerHTML = av.map((t) => `<div class="text-sm bg-amber-50 border border-amber-200 text-amber-800 rounded-xl px-3 py-2">⚠ ${esc(t)}</div>`).join("");
}
function renderChips() {
  const itens = [["TODOS", "Todos"], ["REGULAR", "Regular"], ["ALERTA", "Alerta"], ["CRITICO", "Crítico"], ["DESATIVADO", "Desativado"], ["SEM_CRITERIO", "Sem critério"]];
  $("#chips").innerHTML = itens.map(([k, l]) => `<button class="chip ${state.statusFiltro === k ? "chip-on" : ""}" data-f="${k}">${l}</button>`).join("");
  $$("#chips .chip").forEach((b) => b.addEventListener("click", () => { state.statusFiltro = b.dataset.f; state.page = 0; renderChips(); renderTabela(); }));
}

const COLS = [
  ["prefixo", "Prefixo"], ["tipo_chassi", "Chassi"], ["ano_chassi", "Ano"], ["filial", "Filial"],
  ["km_atual", "KM atual"], ["meta_km", "Meta"], ["km_restante", "Restante"],
  ["meses_restantes", "Tempo"], ["urgencia", "Urgência"], ["status", "Status"], [null, ""],
];
function renderCabecalho() {
  $("#thead").innerHTML = COLS.map(([c, l]) => c
    ? `<th class="th th-sort" data-c="${c}">${l}${state.sort.col === c ? (state.sort.dir === "asc" ? " ▲" : " ▼") : ""}</th>` : `<th class="th">${l}</th>`).join("");
  $$("#thead .th-sort").forEach((th) => th.addEventListener("click", () => {
    const c = th.dataset.c; state.sort = { col: c, dir: state.sort.col === c && state.sort.dir === "desc" ? "asc" : "desc" };
    renderTabela();
  }));
}
function filtrados() {
  const q = state.busca.trim().toLowerCase();
  let rows = state.veiculos.filter((v) => {
    const f = state.statusFiltro;
    if (f === "DESATIVADO" && !v.status.startsWith("DESATIVADO")) return false;
    if (f !== "TODOS" && f !== "DESATIVADO" && v.status !== f) return false;
    return !q || `${v.prefixo} ${v.tipo_chassi} ${v.filial}`.toLowerCase().includes(q);
  });
  const { col, dir } = state.sort, m = dir === "asc" ? 1 : -1;
  return rows.sort((a, b) => {
    const x = a[col], y = b[col];
    if (x == null && y == null) return 0; if (x == null) return 1; if (y == null) return -1;   // vazios sempre no fim
    return (typeof x === "number" ? x - y : String(x).localeCompare(String(y), "pt-BR", { numeric: true })) * m;
  });
}
function tempoTxt(v) {
  if (v.meses_restantes == null) return "—";
  const m = Math.abs(v.meses_restantes), t = `${Math.floor(m / 12)}a ${m % 12}m`;
  return v.meses_restantes < 0 ? `<span class="text-red-600">venc. há ${t}</span>` : t;
}
function renderTabela() {
  renderCabecalho();
  const rows = filtrados(), total = rows.length, pagina = rows.slice(state.page * PAGE, (state.page + 1) * PAGE);
  $("#tbody").innerHTML = pagina.map((v) => {
    const pct = Math.min(100, Math.round(v.urgencia * 100));
    const podeBaixar = v.plano_km && v.meta_km;
    const kmTxt = v.km_atual == null ? `<span class="text-slate-400" title="Sem abastecimento registrado">sem leitura</span>`
      : fmt(v.km_atual) + (v.km_suspeito ? ` <span title="Leitura suspeita; anterior: ${fmt(v.km_alternativo)}" class="text-amber-600">⚠</span>` : "");
    return `<tr class="fade-in">
      <td class="td font-semibold">${esc(v.prefixo)}</td><td class="td">${esc(v.tipo_chassi)}</td>
      <td class="td">${esc(v.ano_chassi)}</td><td class="td">${esc(v.filial)}</td>
      <td class="td text-right">${kmTxt}</td>
      <td class="td text-right">${fmt(v.meta_km)}${v.meta_origem === "ASSUMIDA" ? ` <span title="Sem histórico: meta assumida pelo próximo múltiplo do plano" class="text-slate-400">*</span>` : ""}</td>
      <td class="td text-right ${v.km_restante != null && v.km_restante <= 0 ? "text-red-600 font-semibold" : ""}">${fmt(v.km_restante)}</td>
      <td class="td">${tempoTxt(v)}</td>
      <td class="td"><div class="bar"><i style="width:${pct}%;background:${esc(v.status_cor)}"></i></div></td>
      <td class="td"><span class="badge" style="background:${esc(v.status_cor)}">${esc(v.status_label)}</span></td>
      <td class="td"><button class="btn-ghost !text-emerald-700 font-medium" data-baixa="${esc(v.prefixo)}" ${podeBaixar ? "" : "disabled"}
        title="${podeBaixar ? "Registrar revisão" : "Sem critério ou sem leitura de KM"}">Baixar</button></td></tr>`;
  }).join("") || `<tr><td class="td text-center text-slate-400 py-10" colspan="11">Nenhum veículo encontrado.</td></tr>`;
  $$("[data-baixa]").forEach((b) => b.addEventListener("click", () => abrirBaixa(b.dataset.baixa)));
  const ini = total ? state.page * PAGE + 1 : 0;
  $("#contagem").textContent = `${ini}–${Math.min(total, (state.page + 1) * PAGE)} de ${fmt(total)} veículos`;
  $("#pg-ant").disabled = state.page === 0; $("#pg-prox").disabled = (state.page + 1) * PAGE >= total;
}
$("#busca").addEventListener("input", debounce((e) => { state.busca = e.target.value; state.page = 0; renderTabela(); }));
$("#pg-ant").addEventListener("click", () => { state.page--; renderTabela(); });
$("#pg-prox").addEventListener("click", () => { state.page++; renderTabela(); });

/* ------------------------------- baixa de revisão ----------------------------- */
async function abrirBaixa(prefixo) {
  const v = state.veiculos.find((x) => x.prefixo === prefixo); if (!v) return;
  state.baixaAlvo = v;
  $("#baixa-resumo").textContent = `${v.prefixo} · ${v.tipo_chassi} · ${v.filial}`;
  const prox = v.meta_km + v.plano_km;
  $("#baixa-meta").innerHTML = `KM atual: <b>${fmt(v.km_atual)}</b> · Revisão vigente: <b>${fmt(v.meta_km)} km</b>
    → próxima meta após a baixa: <b class="text-emerald-700">${fmt(prox)} km</b>
    ${v.meta_origem === "ASSUMIDA" ? `<div class="text-xs text-amber-700 mt-1">Meta assumida (sem histórico de revisões deste veículo).</div>` : ""}`;
  $("#baixa-form").reset(); $("#baixa-data").value = new Date().toISOString().slice(0, 10); $("#baixa-data").max = $("#baixa-data").value;
  $("#baixa-erro").classList.add("hidden"); $("#baixa-hist").textContent = "Carregando…"; abrir("#modal-baixa"); $("#baixa-resp").focus();
  try {
    const h = await api(`/api/veiculos/${encodeURIComponent(prefixo)}/historico`);
    $("#baixa-hist").innerHTML = h.revisoes.length ? h.revisoes.map((r) =>
      `<div class="border rounded-lg px-3 py-2"><b>${fmt(r.meta_km_concluida)} km</b> · ${fmtData(r.data)} · NF ${esc(r.nf || "—")}<br><span class="text-slate-500">${esc(r.responsavel)}${r.observacoes ? " — " + esc(r.observacoes) : ""}</span></div>`).join("")
      : `<span class="text-slate-400">Nenhuma revisão registrada.</span>`;
  } catch { $("#baixa-hist").textContent = "Não foi possível carregar o histórico."; }
}
$("#baixa-form").addEventListener("submit", async (e) => {
  e.preventDefault(); const btn = $("#baixa-btn"); btn.disabled = true; $("#baixa-erro").classList.add("hidden");
  try {
    const d = await api("/api/revisoes", { method: "POST", body: {
      prefixo: state.baixaAlvo.prefixo, responsavel: $("#baixa-resp").value, nf: $("#baixa-nf").value,
      data: $("#baixa-data").value, observacoes: $("#baixa-obs").value } });
    $("#modal-baixa").classList.add("hidden");
    toast(`Revisão de ${fmt(d.meta_concluida)} km baixada. Próxima meta: ${fmt(d.proxima_meta)} km.`);
    await carregarPainel();
  } catch (err) { const el = $("#baixa-erro"); el.textContent = err.message; el.classList.remove("hidden"); }
  finally { btn.disabled = false; }
});

/* ------------------------------- novo veículo -------------------------------- */
const normalizarAoDigitar = (inputId, outId) => debounce(async () => {
  const valor = $(inputId).value.trim(), out = $(outId); if (!valor) { out.textContent = ""; return; }
  try {
    const d = await api("/api/chassi/normalizar?valor=" + encodeURIComponent(valor));
    out.innerHTML = `Será gravado como <b>${esc(d.normalizado)}</b> ${d.existe ? "✓ já cadastrado" : "(novo)"}` +
      (!d.existe && d.sugestoes.length ? ` · parecido com: ${d.sugestoes.map((s) => `<button type="button" class="underline text-emerald-700" data-use="${esc(s)}">${esc(s)}</button>`).join(", ")}` : "");
    $$("[data-use]", out).forEach((b) => b.addEventListener("click", () => { $(inputId).value = b.dataset.use; $(inputId).dispatchEvent(new Event("input")); }));
  } catch { /* silencioso: é só um auxílio visual */ }
});
$("#veic-tipo").addEventListener("input", normalizarAoDigitar("#veic-tipo", "#veic-norm"));
$("#crit-tipo").addEventListener("input", normalizarAoDigitar("#crit-tipo", "#crit-norm"));
$("#btn-novo").addEventListener("click", async () => {
  $("#veic-form").reset(); $("#veic-erro").classList.add("hidden"); $("#veic-norm").textContent = "";
  $("#veic-ano").max = new Date().getFullYear() + 1;
  if (state.user.perfil !== "GLOBAL") { $("#veic-filial").value = state.user.filial; $("#veic-filial").disabled = true; }
  else if (state.filial) $("#veic-filial").value = state.filial;
  abrir("#modal-veiculo"); $("#veic-prefixo").focus();
  try { $("#lista-chassis").innerHTML = (await api("/api/chassis")).tipos.map((t) => `<option value="${esc(t)}">`).join(""); } catch {}
});
let confirmarChassi = false;
$("#veic-form").addEventListener("submit", async (e) => {
  e.preventDefault(); const btn = $("#veic-btn"); btn.disabled = true; $("#veic-erro").classList.add("hidden");
  try {
    const d = await api("/api/veiculos", { method: "POST", body: {
      prefixo: $("#veic-prefixo").value, ano_chassi: $("#veic-ano").value, tipo_chassi: $("#veic-tipo").value,
      filial: $("#veic-filial").value, confirmar_chassi_novo: confirmarChassi } });
    confirmarChassi = false; $("#modal-veiculo").classList.add("hidden");
    toast(`Veículo ${d.prefixo} cadastrado.${d.aviso ? " " + d.aviso : ""}`, d.aviso ? "aviso" : "ok"); await carregarPainel();
  } catch (err) {
    const el = $("#veic-erro");
    if (err.data?.codigo === "CHASSI_PARECIDO") {
      confirmarChassi = true;
      el.textContent = `Chassi novo, parecido com: ${err.data.sugestoes.join(", ")}. Corrija o texto ou clique em Cadastrar novamente para confirmar que é um modelo diferente.`;
    } else el.textContent = err.message;
    el.classList.remove("hidden");
  } finally { btn.disabled = false; }
});
$("#veic-tipo").addEventListener("input", () => { confirmarChassi = false; });

/* -------------------------------- critérios ---------------------------------- */
async function carregarCriterios() {
  state.criterios = (await api("/api/criterios")).criterios; renderCriterios(); renderAvisos();
  try { $("#lista-chassis").innerHTML = (await api("/api/chassis")).tipos.map((t) => `<option value="${esc(t)}">`).join(""); } catch {}
}
function tempoCrit(m) { return m % 12 === 0 ? `${m / 12} anos` : `${m} meses`; }
function renderCriterios() {
  const global = state.user.perfil === "GLOBAL";
  $("#crit-tbody").innerHTML = state.criterios.map((c, i) => {
    const editavel = global || c.filial === state.user.filial;
    return `<tr><td class="td font-semibold">${esc(c.tipo_chassi)}</td><td class="td">${c.filial === "*" ? "Todas (padrão)" : esc(c.filial)}</td>
      <td class="td text-right">${fmt(c.plano_km)}</td><td class="td text-right">${tempoCrit(c.tempo_max_meses)}</td>
      <td class="td">${c.revisar === "SIM" ? `<span class="badge" style="background:#F59E0B">Provisório</span>` : `<span class="badge" style="background:#10B981">Revisado</span>`}</td>
      <td class="td text-right">${editavel ? `<button class="btn-ghost" data-edit="${i}">Editar</button><button class="btn-ghost !text-red-600" data-del="${i}">Excluir</button>` : ""}</td></tr>`;
  }).join("") || `<tr><td class="td text-center text-slate-400 py-8" colspan="6">Nenhum critério cadastrado.</td></tr>`;
  $$("[data-edit]").forEach((b) => b.addEventListener("click", () => {
    const c = state.criterios[+b.dataset.edit]; $("#crit-tipo").value = c.tipo_chassi; $("#crit-plano").value = c.plano_km;
    const anos = c.tempo_max_meses % 12 === 0; $("#crit-tempo").value = anos ? c.tempo_max_meses / 12 : c.tempo_max_meses;
    $("#crit-unid").value = anos ? "anos" : "meses"; $("#crit-filial").value = c.filial; window.scrollTo({ top: 0, behavior: "smooth" });
  }));
  $$("[data-del]").forEach((b) => b.addEventListener("click", async () => {
    const c = state.criterios[+b.dataset.del];
    if (!confirm(`Excluir o critério de ${c.tipo_chassi}? Os veículos desse chassi ficarão "sem critério".`)) return;
    loading(true);
    try { await api(`/api/criterios?tipo_chassi=${encodeURIComponent(c.tipo_chassi)}&filial=${encodeURIComponent(c.filial)}`, { method: "DELETE" });
      toast("Critério excluído."); await carregarCriterios(); await carregarPainel(); }
    catch (err) { toast(err.message, "erro"); } finally { loading(false); }
  }));
}
$("#crit-form").addEventListener("submit", async (e) => {
  e.preventDefault(); loading(true);
  try {
    await api("/api/criterios", { method: "POST", body: { tipo_chassi: $("#crit-tipo").value, plano_km: $("#crit-plano").value,
      tempo_max: $("#crit-tempo").value, unidade: $("#crit-unid").value, filial: $("#crit-filial").value } });
    toast("Critério salvo."); $("#crit-form").reset(); $("#crit-norm").textContent = "";
    await carregarCriterios(); await carregarPainel();
  } catch (err) { toast(err.message, "erro"); } finally { loading(false); }
});

/* ---------------------------- abas, modais, teclado --------------------------- */
$$("#tabs .tab").forEach((t) => t.addEventListener("click", () => {
  $$("#tabs .tab").forEach((x) => x.classList.toggle("tab-active", x === t));
  $("#tab-painel").classList.toggle("hidden", t.dataset.tab !== "painel");
  $("#tab-criterios").classList.toggle("hidden", t.dataset.tab !== "criterios");
}));
$$("[data-close]").forEach((b) => b.addEventListener("click", () => fechar(b)));
$$(".modal").forEach((m) => m.addEventListener("mousedown", (e) => { if (e.target === m) m.classList.add("hidden"); }));
document.addEventListener("keydown", (e) => { if (e.key === "Escape") $$(".modal").forEach((m) => m.classList.add("hidden")); });

iniciar();
