import os
import sys
import tempfile
import unittest
from datetime import date

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

import engine
from app import create_app
from normalizer import (levenshtein, meta_inicial_assumida, normalizar_chassi,
                        normalizar_prefixo, proxima_meta, sugerir_similares)
from seed import run_seed
from storage import LocalStore

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
FROTA = os.path.join(ROOT, "input", "FROTA.csv")
ABAST = os.path.join(ROOT, "input", "abastecimento.csv")


class NormalizerTests(unittest.TestCase):
    def test_variacoes_lo916(self):
        for v in ["LO-916", "LO916", "LO 916", "lo-916", "LO-916 EURO VI", " LO  916 euro vi "]:
            self.assertEqual(normalizar_chassi(v), "LO-916", v)

    def test_modelos_distintos_nao_se_fundem(self):
        self.assertNotEqual(normalizar_chassi("OF-1721/59"), normalizar_chassi("OF-1724L/59"))
        self.assertNotEqual(normalizar_chassi("OF-1721/59"), normalizar_chassi("OF-1722M/59"))

    def test_variacoes_reais_da_frota(self):
        self.assertEqual(normalizar_chassi("OF 1519R/60 EURO VI"), normalizar_chassi("OF-1519R/60"))
        self.assertEqual(normalizar_chassi("OF1621/59 EURO VI"), "OF-1621/59")
        self.assertEqual(normalizar_chassi("O500 R 1931 EURO VI"), "O-500R 1931")

    def test_vazio(self):
        self.assertEqual(normalizar_chassi(None), "")
        self.assertEqual(normalizar_chassi("   "), "")

    def test_levenshtein_e_sugestao(self):
        self.assertEqual(levenshtein("kitten", "sitting"), 3)
        self.assertEqual(sugerir_similares("OF-1721/58", ["OF-1721/59", "LO-916"]), ["OF-1721/59"])

    def test_prefixo(self):
        self.assertEqual(normalizar_prefixo("2070"), "02070")
        self.assertEqual(normalizar_prefixo(" m0940 "), "M0940")


class CicloTests(unittest.TestCase):
    def test_progressao(self):
        self.assertEqual(proxima_meta(30000, 30000), 60000)
        self.assertEqual(proxima_meta(30000, 60000), 90000)

    def test_meta_assumida(self):
        self.assertEqual(meta_inicial_assumida(30000, 0), 30000)
        self.assertEqual(meta_inicial_assumida(30000, 29999), 30000)
        self.assertEqual(meta_inicial_assumida(30000, 30000), 60000)


class MotorTests(unittest.TestCase):
    HOJE = date(2026, 10, 7)
    CRIT = {"tipo_chassi": "X", "filial": "*", "plano_km": 30000, "tempo_max_meses": 15 * 12}

    def av(self, ano, km, ultima=None):
        v = {"prefixo": "1", "filial": "F", "tipo_chassi": "X", "ano_chassi": ano}
        info = {"km": km, "suspeito": False, "km_alternativo": None} if km is not None else None
        return engine.avaliar_veiculo(v, self.CRIT, info, ultima, self.HOJE)

    def test_km_atual_e_o_maior_registro(self):
        ab = [{"prefixo": "A", "km_registrada": 100}, {"prefixo": "A", "km_registrada": 250},
              {"prefixo": "A", "km_registrada": 180}]
        self.assertEqual(engine.km_atual_por_veiculo(ab)["A"]["km"], 250)

    def test_km_suspeito(self):
        ab = [{"prefixo": "A", "km_registrada": 258921}, {"prefixo": "A", "km_registrada": 2155451}]
        self.assertTrue(engine.km_atual_por_veiculo(ab)["A"]["suspeito"])

    def test_desativado_por_tempo(self):
        self.assertEqual(self.av(2011, 1000)["status"], "DESATIVADO_TEMPO")   # 15a9m > 15a

    def test_alerta_por_tempo(self):
        self.assertEqual(self.av(2012, 1000)["status"], "ALERTA")             # faltam 3 meses

    def test_regular(self):
        self.assertEqual(self.av(2022, 5000)["status"], "REGULAR")

    def test_alerta_e_critico_por_km(self):
        ult = {"proxima_meta_km": 60000, "data": "2026-01-01"}
        self.assertEqual(self.av(2022, 57500, ult)["status"], "ALERTA")
        self.assertEqual(self.av(2022, 60000, ult)["status"], "CRITICO")
        self.assertEqual(self.av(2022, 65000, ult)["status"], "CRITICO")

    def test_sem_criterio(self):
        v = {"prefixo": "1", "filial": "F", "tipo_chassi": "Y", "ano_chassi": 2020}
        self.assertEqual(engine.avaliar_veiculo(v, None, None, None, self.HOJE)["status"], "SEM_CRITERIO")

    def test_sem_leitura_km_usa_so_tempo(self):
        r = self.av(2022, None)
        self.assertTrue(r["sem_leitura_km"])
        self.assertEqual(r["status"], "REGULAR")


class ApiTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.store = LocalStore(tempfile.mkdtemp())
        res = run_seed(cls.store, FROTA, ABAST)
        cls.creds = {l.split("\t")[0]: l.split("\t")[1] for l in res["credenciais"]}
        cls.app = create_app(cls.store).test_client()

    def login(self, email):
        r = self.app.post("/api/login", json={"email": email, "senha": self.creds[email]})
        self.assertEqual(r.status_code, 200)
        return {"Authorization": "Bearer " + r.get_json()["token"]}

    def test_login_invalido(self):
        r = self.app.post("/api/login", json={"email": "admin@frota.local", "senha": "errada"})
        self.assertEqual(r.status_code, 401)
        self.assertEqual(self.app.get("/api/veiculos").status_code, 401)

    def test_rbac_global_ve_tudo_e_filial_so_a_sua(self):
        g = self.app.get("/api/veiculos", headers=self.login("admin@frota.local")).get_json()
        self.assertEqual(g["kpis"]["total"], len(self.store.list("Veiculos")))
        h = self.login("filial.vale@frota.local")
        f = self.app.get("/api/veiculos", headers=h).get_json()
        self.assertTrue(0 < f["kpis"]["total"] < g["kpis"]["total"])
        self.assertTrue(all(v["filial"] == "FILIAL VALE" for v in f["veiculos"]))
        r = self.app.get("/api/veiculos?filial=GARAGEM ITAUNA", headers=h)
        self.assertEqual(r.status_code, 403)

    def test_baixa_progride_ciclo_e_valida(self):
        h = self.login("admin@frota.local")
        alvo = next(v for v in self.app.get("/api/veiculos", headers=h).get_json()["veiculos"]
                    if v["meta_km"] and v["plano_km"])
        corpo = {"prefixo": alvo["prefixo"], "responsavel": "Maria Souza", "nf": "NF-1001",
                 "data": "2026-10-01", "observacoes": "troca de óleo"}
        self.assertEqual(self.app.post("/api/revisoes", headers=h, json={**corpo, "responsavel": "Maria"}).status_code, 400)
        self.assertEqual(self.app.post("/api/revisoes", headers=h, json={**corpo, "data": "2099-01-01"}).status_code, 400)
        r = self.app.post("/api/revisoes", headers=h, json=corpo)
        self.assertEqual(r.status_code, 201)
        j = r.get_json()
        self.assertEqual(j["meta_concluida"], alvo["meta_km"])
        self.assertEqual(j["proxima_meta"], alvo["meta_km"] + alvo["plano_km"])
        self.assertEqual(j["veiculo"]["meta_origem"], "REVISAO")
        self.assertEqual(self.app.post("/api/revisoes", headers=h, json=corpo).status_code, 409)  # NF repetida
        hist = self.app.get(f"/api/veiculos/{alvo['prefixo']}/historico", headers=h).get_json()
        self.assertEqual(len(hist["revisoes"]), 1)

    def test_baixa_fora_do_escopo(self):
        adm = self.login("admin@frota.local")
        outro = next(v for v in self.app.get("/api/veiculos?filial=GARAGEM ITAUNA", headers=adm).get_json()["veiculos"])
        h = self.login("filial.vale@frota.local")
        r = self.app.post("/api/revisoes", headers=h, json={
            "prefixo": outro["prefixo"], "responsavel": "Joao Silva", "nf": "X1", "data": "2026-10-01"})
        self.assertEqual(r.status_code, 404)

    def test_baixa_sem_leitura_de_km_e_recusada(self):
        h = self.login("admin@frota.local")
        v = next(v for v in self.app.get("/api/veiculos", headers=h).get_json()["veiculos"]
                 if v["sem_leitura_km"] and v["plano_km"])
        r = self.app.post("/api/revisoes", headers=h, json={
            "prefixo": v["prefixo"], "responsavel": "Ana Lima", "nf": "S1", "data": "2026-10-01"})
        self.assertEqual(r.status_code, 422)

    def test_cadastro_veiculo(self):
        h = self.login("filial.vale@frota.local")
        base = {"prefixo": "zz999", "ano_chassi": 2024, "tipo_chassi": "lo916 euro vi", "filial": "OUTRA"}
        r = self.app.post("/api/veiculos", headers=h, json=base)
        self.assertEqual(r.status_code, 201)
        self.assertEqual(r.get_json()["tipo_chassi"], "LO-916")
        self.assertEqual(self.app.post("/api/veiculos", headers=h, json=base).status_code, 409)
        v = next(v for v in self.app.get("/api/veiculos", headers=h).get_json()["veiculos"] if v["prefixo"] == "ZZ999")
        self.assertEqual(v["filial"], "FILIAL VALE")   # filial do operador prevalece

    def test_criterios_operador_so_edita_propria_filial(self):
        h = self.login("filial.vale@frota.local")
        r = self.app.post("/api/criterios", headers=h, json={
            "tipo_chassi": "LO916", "filial": "GARAGEM ITAUNA", "plano_km": 20000, "tempo_max": 10, "unidade": "anos"})
        self.assertEqual(r.status_code, 200)
        self.assertEqual(r.get_json()["filial"], "FILIAL VALE")
        self.assertEqual(r.get_json()["tempo_max_meses"], 120)


if __name__ == "__main__":
    unittest.main()
